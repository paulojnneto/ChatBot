public class CreateBotDto
{
    public string Name { get; set; }
    public string Context { get; set; }
}