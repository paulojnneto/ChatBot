public class SendMessageDto
{
    public int BotId { get; set; }
    public string UserMessage { get; set; }
}
